import "./QuickView.css";
import { AiFillStar } from "react-icons/ai";
import { useNavigate } from "react-router-dom";
import { useCart } from "../../context/CartContext";
import { Product } from "../../types/Product";

type Props = {
  product: Product;
  onClose: () => void;
};

const QuickView = ({
  product,
  onClose,
}: Props) => {
  const navigate = useNavigate();
  const { addToCart } = useCart();

  if (!product) return null;

  const categoryName =
    typeof product.category === "string"
      ? product.category
      : product.category.name;

  return (
    <div
      className="quickview-overlay"
      onClick={onClose}
    >
      <div
        className="quickview-modal"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          className="close-modal"
          onClick={onClose}
        >
          ✕
        </button>

        <img
          src={product.images[0]}
          alt={product.name}
        />

        <h2>{product.name}</h2>

        <div className="quick-rating">
          <AiFillStar />
          <span>
            {product.ratings.average}
          </span>
        </div>

        <h3>
          ₦{product.basePrice.toLocaleString()}
        </h3>

        <p>{categoryName}</p>

        <p>{product.description}</p>

        <div className="quick-buttons">
          <button
            onClick={() =>
              navigate(`/product/${product._id}`)
            }
          >
            View Details
          </button>

          <button
            onClick={() => {
              addToCart(product);
            }}
          >
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
};

export default QuickView;