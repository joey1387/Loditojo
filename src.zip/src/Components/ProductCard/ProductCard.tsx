import "./ProductCard.css";
import { useCart } from "../../context/CartContext";
import { useWishlist } from "../../context/WishlistContext";
import { useCompare } from "../../context/CompareContext";
import {
  AiOutlineHeart,
  AiFillHeart,
  AiFillStar,
} from "react-icons/ai";
import {
  FaShoppingCart,
  FaEye,
  FaBalanceScale,
} from "react-icons/fa";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import QuickView from "../QuickView/QuickView";
import { Product } from "../../types/Product";

type ProductCardProps = Product;

const ProductCard = (product: ProductCardProps) => {
  const {
    _id,
    name,
    category,
    basePrice,
    ratings,
    stock,
    isFeatured,
    images,
  } = product;

  const { addToCart } = useCart();

  const {
    addToWishlist,
    removeFromWishlist,
    isInWishlist,
  } = useWishlist();

  const {
    addToCompare,
    removeFromCompare,
    isInCompare,
  } = useCompare();

  const navigate = useNavigate();

  const [showQuickView, setShowQuickView] =
    useState(false);

  const categoryName =
    typeof category === "string"
      ? category
      : category.name;

  return (
    <div
      className="product-card"
      onClick={() =>
        navigate(`/product/${_id}`)
      }
    >
      <div className="product-image-box">
        <img
          src={images[0]}
          alt={name}
        />
      </div>

      {showQuickView && (
        <QuickView
          product={product}
          onClose={() =>
            setShowQuickView(false)
          }
        />
      )}

      <button
        className="wishlist-btn"
        onClick={(e) => {
          e.stopPropagation();

          if (isInWishlist(_id)) {
            removeFromWishlist(_id);
            toast.info(
              "Removed from Wishlist"
            );
          } else {
            addToWishlist(product);
            toast.success(
              "Added to Wishlist"
            );
          }
        }}
      >
        {isInWishlist(_id) ? (
          <AiFillHeart />
        ) : (
          <AiOutlineHeart />
        )}
      </button>

      <button
        className="compare-btn"
        onClick={(e) => {
          e.stopPropagation();

          if (isInCompare(_id)) {
            removeFromCompare(_id);
            toast.info(
              "Removed from Compare"
            );
          } else {
            addToCompare(product);
            toast.success(
              "Added to Compare"
            );
          }
        }}
      >
        <FaBalanceScale />
      </button>

      <button
        className="quick-view-btn"
        onClick={(e) => {
          e.stopPropagation();
          setShowQuickView(true);
        }}
      >
        <FaEye />
      </button>

      {isFeatured && (
        <span className="featured-badge">
          Featured
        </span>
      )}

      <div className="card-content">
        <span className="category">
          {categoryName}
        </span>

        <h3>{name}</h3>

        <div className="rating">
          <AiFillStar />
          <span>{ratings.average}</span>
        </div>

        <p className="price">
          ₦{basePrice.toLocaleString()}
        </p>

        <p
          className={
            stock > 0
              ? "in-stock"
              : "out-stock"
          }
        >
          {stock > 0
            ? `${stock} in stock`
            : "Out of stock"}
        </p>

        <button
          className="add-cart-btn"
          onClick={(e) => {
            e.stopPropagation();

            addToCart(product);

            toast.success(
              "Product added to cart!"
            );
          }}
        >
          <FaShoppingCart />
          Add to Cart
        </button>
      </div>
    </div>
  );
};

export default ProductCard;