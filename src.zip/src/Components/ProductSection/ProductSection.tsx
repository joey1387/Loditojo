import "./ProductSection.css";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import ProductCard from "../ProductCard/ProductCard";
import Skeleton from "../Skeleton/Skeleton";

import { getProducts } from "../../api/productApi";

const ProductSection = () => {
  const navigate = useNavigate();

  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const data = await getProducts();
        setProducts(data);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const featuredProducts = products.filter(
    (product) => product.isFeatured
  );

  return (
    <section className="product-section">
      <div className="section-top">
        <span className="section-tag">
          FEATURED COLLECTION
        </span>

        <h2>Trending Gadgets</h2>

        <p>
          Handpicked premium gadgets with
          unbeatable prices, top performance
          and nationwide delivery.
        </p>
      </div>

      <div className="products-grid">
        {loading ? (
          Array.from({ length: 4 }).map((_, index) => (
            <Skeleton key={index} />
          ))
        ) : (
          featuredProducts.map((product) => (
            <ProductCard
              key={product._id}
              id={product._id}
              name={product.name}
              category={product.category.name}
              price={product.basePrice}
              rating={product.ratings.average}
              stock={product.stock}
              featured={product.isFeatured}
              image={product.images[0]}
              description={product.description}
              specifications={{
                brand: product.brand,
                model: product.name,
                color: "N/A",
                storage:
                  product.specs?.Storage ??
                  "N/A",
                display: "N/A",
                battery: "N/A",
                warranty: "N/A",
              }}
              reviews={[]}
            />
          ))
        )}
      </div>

      <div className="view-all-container">
        <button
          className="view-all-btn"
          onClick={() => navigate("/shop")}
        >
          View All Products →
        </button>
      </div>
    </section>
  );
};

export default ProductSection;