import React, { useEffect, useState } from "react";
import  DashboardLayout  from "../../components/DashboardLayout";

interface PendingSeller {
  _id: string;
  name: string;
  email: string;
  storeName?: string;
  createdAt: string;
}

export const AdminDashboard: React.FC = () => {
  const [pendingSellers, setPendingSellers] = useState<PendingSeller[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [message, setMessage] = useState<{ text: string; type: "success" | "error" } | null>(null);

  const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:5000";

  const fetchPendingSellers = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem("token");
      if (!token) {
        setMessage({ text: "Authentication token missing. Please log in again.", type: "error" });
        return;
      }

      const res = await fetch(`${API_BASE}/api/user/pending-sellers`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();

      if (res.ok) {
        setPendingSellers(data.data || data);
      } else {
        setMessage({ text: data.message || "Failed to fetch pending sellers.", type: "error" });
      }
    } catch (err) {
      console.error("Failed to load pending sellers:", err);
      setMessage({ text: "Network error loading applications.", type: "error" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPendingSellers();
  }, []);

  const handleSellerAction = async (id: string, action: "approve" | "reject") => {
    try {
      const token = localStorage.getItem("token");
      const res = await fetch(`${API_BASE}/api/user/handle-seller/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ action }),
      });

      const data = await res.json();

      if (res.ok) {
        setMessage({
          text: `Seller application successfully ${action}d!`,
          type: "success",
        });
        // Optimistic UI update before re-fetching
        setPendingSellers((prev) => prev.filter((s) => s._id !== id));
      } else {
        setMessage({ text: data.message || `Failed to ${action} seller.`, type: "error" });
      }
    } catch (err) {
      setMessage({ text: "An error occurred. Please try again.", type: "error" });
    }
  };

  return (
    <DashboardLayout role="admin">
      <h1 style={{ fontSize: "24px", fontWeight: "bold", marginBottom: "20px", color: "#1e1b4b" }}>
        Admin Dashboard
      </h1>

      {message && (
        <div
          style={{
            padding: "12px",
            backgroundColor: message.type === "success" ? "#dcfce7" : "#fee2e2",
            color: message.type === "success" ? "#15803d" : "#b91c1c",
            borderRadius: "6px",
            marginBottom: "20px",
          }}
        >
          {message.text}
        </div>
      )}

      {/* Stats Cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "20px", marginBottom: "30px" }}>
        <div style={{ padding: "20px", backgroundColor: "#fff", borderRadius: "10px", boxShadow: "0 2px 5px rgba(0,0,0,0.05)" }}>
          <p style={{ color: "#6b7280", fontSize: "14px" }}>Pending Applications</p>
          <h2 style={{ fontSize: "28px", fontWeight: "bold", color: "#6b21a8", marginTop: "5px" }}>
            {pendingSellers.length}
          </h2>
        </div>
        <div style={{ padding: "20px", backgroundColor: "#fff", borderRadius: "10px", boxShadow: "0 2px 5px rgba(0,0,0,0.05)" }}>
          <p style={{ color: "#6b7280", fontSize: "14px" }}>Platform Status</p>
          <h2 style={{ fontSize: "28px", fontWeight: "bold", color: "#16a34a", marginTop: "5px" }}>Active</h2>
        </div>
        <div style={{ padding: "20px", backgroundColor: "#fff", borderRadius: "10px", boxShadow: "0 2px 5px rgba(0,0,0,0.05)" }}>
          <p style={{ color: "#6b7280", fontSize: "14px" }}>System Security</p>
          <h2 style={{ fontSize: "28px", fontWeight: "bold", color: "#2563eb", marginTop: "5px" }}>Encrypted</h2>
        </div>
      </div>

      {/* Pending Sellers Table */}
      <div style={{ backgroundColor: "#fff", padding: "20px", borderRadius: "10px", boxShadow: "0 2px 5px rgba(0,0,0,0.05)" }}>
        <h3 style={{ fontSize: "18px", fontWeight: "bold", marginBottom: "15px", color: "#1e1b4b" }}>
          Pending Seller Approvals
        </h3>

        {loading ? (
          <p>Loading requests...</p>
        ) : pendingSellers.length === 0 ? (
          <p style={{ color: "#6b7280" }}>No pending seller applications at this time.</p>
        ) : (
          <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left" }}>
            <thead>
              <tr style={{ borderBottom: "2px solid #f3f4f6", color: "#4b5563" }}>
                <th style={{ padding: "10px" }}>Applicant Name</th>
                <th style={{ padding: "10px" }}>Email</th>
                <th style={{ padding: "10px" }}>Store Name</th>
                <th style={{ padding: "10px" }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {pendingSellers.map((seller) => (
                <tr key={seller._id} style={{ borderBottom: "1px solid #f3f4f6" }}>
                  <td style={{ padding: "12px 10px" }}>{seller.name}</td>
                  <td style={{ padding: "12px 10px" }}>{seller.email}</td>
                  <td style={{ padding: "12px 10px" }}>{seller.storeName || "N/A"}</td>
                  <td style={{ padding: "12px 10px", display: "flex", gap: "10px" }}>
                    <button
                      onClick={() => handleSellerAction(seller._id, "approve")}
                      style={{
                        padding: "6px 12px",
                        backgroundColor: "#16a34a",
                        color: "#fff",
                        border: "none",
                        borderRadius: "4px",
                        cursor: "pointer",
                      }}
                    >
                      Approve
                    </button>
                    <button
                      onClick={() => handleSellerAction(seller._id, "reject")}
                      style={{
                        padding: "6px 12px",
                        backgroundColor: "#dc2626",
                        color: "#fff",
                        border: "none",
                        borderRadius: "4px",
                        cursor: "pointer",
                      }}
                    >
                      Reject
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </DashboardLayout>
  );
};