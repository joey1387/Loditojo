import React, { useEffect, useState } from "react";
import  DashboardLayout  from "../../components/DashboardLayout";

interface Product {
  _id: string;
  name: string;
  price: number;
  stock: number;
  category: string;
}

export const SellerDashboard: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [stats, setStats] = useState({ totalProducts: 0, totalSales: 0 });
  const [loading, setLoading] = useState<boolean>(true);

  const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:5000";

  useEffect(() => {
    const fetchSellerData = async () => {
      try {
        const token = localStorage.getItem("token");

        // Fetch both products and stats concurrently for faster loading
        const [prodRes, statsRes] = await Promise.all([
          fetch(`${API_BASE}/api/products/seller/my-products`, {
            headers: { Authorization: `Bearer ${token}` },
          }),
          fetch(`${API_BASE}/api/products/seller/my-stats`, {
            headers: { Authorization: `Bearer ${token}` },
          }),
        ]);

        if (prodRes.ok) {
          const prodData = await prodRes.json();
          setProducts(prodData.data || prodData);
        }

        if (statsRes.ok) {
          const statsData = await statsRes.json();
          setStats(statsData.data || statsData);
        }
      } catch (err) {
        console.error("Error fetching seller details:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchSellerData();
  }, [API_BASE]);

  return (
    <DashboardLayout role="seller">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
        <h1 style={{ fontSize: "24px", fontWeight: "bold", color: "#1e1b4b" }}>Seller Dashboard</h1>
        <button
          style={{
            padding: "10px 18px",
            backgroundColor: "#6b21a8",
            color: "#fff",
            border: "none",
            borderRadius: "6px",
            cursor: "pointer",
            fontWeight: "bold",
          }}
        >
          + Add New Product
        </button>
      </div>

      {/* Metrics Row */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "20px", marginBottom: "30px" }}>
        <div style={{ padding: "20px", backgroundColor: "#fff", borderRadius: "10px", boxShadow: "0 2px 5px rgba(0,0,0,0.05)" }}>
          <p style={{ color: "#6b7280", fontSize: "14px" }}>Total Live Listings</p>
          <h2 style={{ fontSize: "28px", fontWeight: "bold", color: "#6b21a8", marginTop: "5px" }}>
            {stats.totalProducts || products.length}
          </h2>
        </div>
        <div style={{ padding: "20px", backgroundColor: "#fff", borderRadius: "10px", boxShadow: "0 2px 5px rgba(0,0,0,0.05)" }}>
          <p style={{ color: "#6b7280", fontSize: "14px" }}>Completed Orders</p>
          <h2 style={{ fontSize: "28px", fontWeight: "bold", color: "#16a34a", marginTop: "5px" }}>
            {stats.totalSales || 0}
          </h2>
        </div>
      </div>

      {/* Seller Inventory */}
      <div style={{ backgroundColor: "#fff", padding: "20px", borderRadius: "10px", boxShadow: "0 2px 5px rgba(0,0,0,0.05)" }}>
        <h3 style={{ fontSize: "18px", fontWeight: "bold", marginBottom: "15px", color: "#1e1b4b" }}>Your Inventory</h3>

        {loading ? (
          <p>Loading products...</p>
        ) : products.length === 0 ? (
          <p style={{ color: "#6b7280" }}>You haven't added any products yet.</p>
        ) : (
          <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left" }}>
            <thead>
              <tr style={{ borderBottom: "2px solid #f3f4f6", color: "#4b5563" }}>
                <th style={{ padding: "10px" }}>Product Name</th>
                <th style={{ padding: "10px" }}>Price (NGN)</th>
                <th style={{ padding: "10px" }}>Stock</th>
                <th style={{ padding: "10px" }}>Status</th>
              </tr>
            </thead>
            <tbody>
              {products.map((prod) => (
                <tr key={prod._id} style={{ borderBottom: "1px solid #f3f4f6" }}>
                  <td style={{ padding: "12px 10px", fontWeight: "500" }}>{prod.name}</td>
                  <td style={{ padding: "12px 10px" }}>₦{prod.price?.toLocaleString()}</td>
                  <td style={{ padding: "12px 10px" }}>{prod.stock} units</td>
                  <td style={{ padding: "12px 10px" }}>
                    <span
                      style={{
                        padding: "4px 8px",
                        borderRadius: "4px",
                        fontSize: "12px",
                        backgroundColor: prod.stock > 0 ? "#dcfce7" : "#fee2e2",
                        color: prod.stock > 0 ? "#15803d" : "#b91c1c",
                      }}
                    >
                      {prod.stock > 0 ? "In Stock" : "Out of Stock"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </DashboardLayout>
  );
};