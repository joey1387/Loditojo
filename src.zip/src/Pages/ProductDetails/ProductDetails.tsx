import "./ProductDetails.css";
import { useNavigate, useParams } from "react-router-dom";
import { AiFillStar } from "react-icons/ai";
import { useCart } from "../../context/CartContext";
import { useState, useEffect } from "react";
import ProductCard from "../../Components/ProductCard/ProductCard";
import {
  saveRecentlyViewed,
  getRecentlyViewed,
} from "../../utils/recentlyViewed";

import {
  getProducts,
  getSingleProduct,
} from "../../api/productApi";

import { Product } from "../../types/Product";

const ProductDetails = () => {
  const { id } = useParams();

  const navigate = useNavigate();

  const { addToCart } = useCart();

  const [product, setProduct] =
    useState<Product | null>(null);

  const [products, setProducts] =
    useState<Product[]>([]);

  const [loading, setLoading] =
    useState(true);

  const [quantity, setQuantity] =
    useState(1);

  const [selectedImage, setSelectedImage] =
    useState("");

  const [recentProducts, setRecentProducts] =
    useState<Product[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const single =
          await getSingleProduct(id!);

        const all =
          await getProducts();

        setProduct(single);

        setProducts(all);

        setSelectedImage(single.images[0]);

        saveRecentlyViewed(single._id);

        setRecentProducts(getRecentlyViewed(all));
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id]);

  if (loading)
    return <h2>Loading...</h2>;

  if (!product)
    return <h2>Product not found.</h2>;

  const relatedProducts = products.filter(
    (p) =>
      p.category._id ===
        product.category._id &&
      p._id !== product._id
  );

  return (
    <>
      <section className="product-details">
        <div className="product-image">
          <img
            className="main-product-image"
            src={selectedImage}
            alt={product.name}
          />

          <div className="thumbnail-images">
            {product.images.map(
              (image, index) => (
                <img
                  key={index}
                  src={image}
                  alt={product.name}
                  onClick={() =>
                    setSelectedImage(image)
                  }
                />
              )
            )}
          </div>
        </div>

        <div className="product-info">
          <span className="product-category">
            {product.category.name.toUpperCase()}
          </span>

          <h1>{product.name}</h1>

          <div className="product-rating">
            <AiFillStar />

            <span>
              {product.ratings.average}
            </span>

            <small>
              (
              {product.ratings.count} Reviews)
            </small>
          </div>

          <h2>
            ₦
            {product.basePrice.toLocaleString()}
          </h2>

          <p>{product.description}</p>

          <p
            className={`stock ${
              product.stock > 0
                ? "in-stock"
                : "out-stock"
            }`}
          >
            {product.stock > 0
              ? `🟢 In Stock (${product.stock})`
              : "🔴 Out of Stock"}
          </p>

          <div className="delivery-card">
            <div className="delivery-item">
              <span>🚚</span>

              <div>
                <h4>
                  Fast Delivery
                </h4>

                <p>
                  Delivered within
                  2–5 business days.
                </p>
              </div>
            </div>

            <div className="delivery-item">
              <span>🔒</span>

              <div>
                <h4>
                  Secure Payment
                </h4>

                <p>
                  Pay securely with
                  Paystack or
                  Flutterwave.
                </p>
              </div>
            </div>

            <div className="delivery-item">
              <span>🛡️</span>

              <div>
                <h4>Warranty</h4>

                <p>
                  Manufacturer
                  warranty available
                  on eligible
                  products.
                </p>
              </div>
            </div>
          </div>

          <div className="specifications-card">
            <h3>Specifications</h3>

            <div className="spec-grid">
              <div>
                <span>Brand</span>

                <strong>
                  {product.brand}
                </strong>
              </div>

              {Object.entries(
                product.specs
              ).map(
                ([key, value]) => (
                  <div key={key}>
                    <span>{key}</span>

                    <strong>
                      {String(value)}
                    </strong>
                  </div>
                )
              )}
            </div>
          </div>

          <div className="quantity-section">
            <h4>Quantity</h4>

            <div className="quantity-box">
              <button
                onClick={() =>
                  setQuantity((q) =>
                    Math.max(1, q - 1)
                  )
                }
              >
                -
              </button>

              <span>{quantity}</span>

              <button
                onClick={() =>
                  setQuantity(
                    (q) => q + 1
                  )
                }
              >
                +
              </button>
            </div>
          </div>

          <div className="product-buttons">
            <button
              className="add-cart"
              onClick={() => {
                for (
                  let i = 0;
                  i < quantity;
                  i++
                ) {
                  addToCart(product);
                }
              }}
            >
              Add to Cart
            </button>

            <button
              className="buy-now"
              onClick={() => {
                for (
                  let i = 0;
                  i < quantity;
                  i++
                ) {
                  addToCart(product);
                }

                navigate("/checkout");
              }}
            >
              Buy Now
            </button>
          </div>
        </div>
      </section>

      <section className="reviews-section">
        <div className="reviews-header">
          <div>
            <h2>Customer Reviews</h2>

            <div className="overall-rating">
              ⭐⭐⭐⭐⭐

              <h1>
                {product.ratings.average}/5
              </h1>

              <p>
                Based on{" "}
                {product.ratings.count} Reviews
              </p>
            </div>
          </div>

          <div className="rating-bars">
            <div>
              <span>★★★★★</span>

              <div className="bar">
                <div
                  className="fill"
                  style={{
                    width: `${product.ratings.average * 20}%`,
                  }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        {product.reviews &&
        product.reviews.length > 0 ? (
          product.reviews.map(
            (review, index) => (
              <div
                key={index}
                className="review-card"
              >
                <h4>{review.name}</h4>

                <div className="review-rating">
                  {"⭐".repeat(
                    review.rating
                  )}
                </div>

                <p>{review.comment}</p>

                <small>
                  {review.date}
                </small>
              </div>
            )
          )
        ) : (
          <p>
            No reviews yet for this
            product.
          </p>
        )}
      </section>

      <section className="related-products">
        <div className="section-header">
          <h2>You May Also Like</h2>

          <p>
            More products in this
            category
          </p>
        </div>

        <div className="related-grid">
          {relatedProducts
            .slice(0, 4)
            .map((item) => (
              <ProductCard
                key={item._id}
                {...item}
              />
            ))}
        </div>
      </section>

      <section className="related-products">
        <div className="section-header">
          <h2>Recently Viewed</h2>

          <p>
            Continue where you left
            off
          </p>
        </div>

        <div className="related-grid">
          {recentProducts
            .filter(
              (item) =>
                item._id !== product._id
            )
            .slice(0, 4)
            .map((item) => (
              <ProductCard
                key={item._id}
                {...item}
              />
            ))}
        </div>
      </section>
    </>
  );
};

export default ProductDetails;